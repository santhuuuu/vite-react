import { ContentItem, Season } from './types';

// Default seasons structure to ensure all series have visible episodes
const DEFAULT_SEASONS: Season[] = [
  {
    id: 's1',
    title: 'Season 1: Core Curriculum',
    episodes: [
      { 
        id: 'ep1', 
        title: 'Episode 1: The Foundation', 
        duration: '45m', 
        description: 'We begin our journey by establishing the core principles and understanding the landscape of this domain.', 
        thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=400&auto=format&fit=crop',
        isCompleted: true
      },
      { 
        id: 'ep2', 
        title: 'Episode 2: Core Methodologies', 
        duration: '52m', 
        description: 'Deep diving into the standard methodologies used by industry professionals today.', 
        thumbnail: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=400&auto=format&fit=crop' 
      },
      { 
        id: 'ep3', 
        title: 'Episode 3: Advanced Concepts', 
        duration: '58m', 
        description: 'Moving beyond the basics to explore complex scenarios and edge cases.', 
        thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=400&auto=format&fit=crop' 
      },
      { 
        id: 'ep4', 
        title: 'Episode 4: Practical Application', 
        duration: '1h 05m', 
        description: 'Applying everything we have learned so far into a real-world project simulation.', 
        thumbnail: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=400&auto=format&fit=crop' 
      },
      { 
        id: 'ep5', 
        title: 'Episode 5: Masterclass Review', 
        duration: '48m', 
        description: 'A comprehensive review and expert tips to master the subject matter.', 
        thumbnail: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=400&auto=format&fit=crop' 
      }
    ]
  }
];

export const CONTENT_DATA: ContentItem[] = [
  // --- CSE / IT SERIES & MOVIES ---

  // 1. Gen-AI & Prompt Engineering (Featured)
  {
    id: 'gen-ai-1',
    type: 'series',
    title: 'Gen-AI & Prompt Engineering',
    description: 'Master the art of communicating with Large Language Models. From zero-shot prompting to building agents with LangChain and creating generative art.',
    instructor: 'Dr. Sarah Connor',
    category: 'CSE / IT',
    rating: '99% Match',
    year: 2024,
    duration: '2 Seasons',
    // Futuristic Brain / AI
    thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=1920&auto=format&fit=crop',
    tags: ['GenAI', 'Prompt Engineering', 'LLMs'],
    seasons: [
      {
        id: 's1',
        title: 'Season 1: Prompting Basics',
        episodes: [
          { id: 'ga-1', title: 'The Art of the Prompt', duration: '45m', description: 'Introduction to LLMs and context windows.', thumbnail: 'https://images.unsplash.com/photo-1684369176170-46eb59339237?q=80&w=400&auto=format&fit=crop', isCompleted: true },
          { id: 'ga-2', title: 'Chain of Thought', duration: '50m', description: 'Advanced reasoning patterns for complex tasks.', thumbnail: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=400&auto=format&fit=crop' }
        ]
      }
    ]
  },

  // 2. MERN Stack
  {
    id: 'mern-1',
    type: 'series',
    title: 'MERN Stack Mastery',
    description: 'Build robust full-stack applications using MongoDB, Express, React, and Node.js. The complete guide to modern web development.',
    instructor: 'Dev Guru',
    category: 'CSE / IT',
    rating: '98% Match',
    year: 2024,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1633356122102-3fe601e15fae?q=80&w=1920&auto=format&fit=crop',
    tags: ['React', 'NodeJS', 'MongoDB'],
    seasons: DEFAULT_SEASONS
  },

  // 3. Data Science & Analytics
  {
    id: 'ds-1',
    type: 'series',
    title: 'Data Science & Analytics',
    description: 'Uncover insights from raw data. Learn Python, Pandas, and statistical analysis techniques used by top data scientists.',
    instructor: 'Prof. Alan Turing',
    category: 'CSE / IT',
    rating: '97% Match',
    year: 2023,
    duration: '4 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?q=80&w=1920&auto=format&fit=crop',
    tags: ['Python', 'Data', 'Statistics'],
    seasons: DEFAULT_SEASONS
  },

  // 4. Full Stack Web Development
  {
    id: 'fs-1',
    type: 'series',
    title: 'Full Stack Web Development',
    description: 'The ultimate bootcamp. From HTML/CSS to database management and server deployment. Become a versatile developer.',
    instructor: 'Code Academy',
    category: 'CSE / IT',
    rating: '95% Match',
    year: 2024,
    duration: '5 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1517134191118-9d595e4c8c2b?q=80&w=1920&auto=format&fit=crop',
    tags: ['Web', 'Frontend', 'Backend'],
    seasons: DEFAULT_SEASONS
  },

  // 5. .NET Full Stack
  {
    id: 'dotnet-1',
    type: 'series',
    title: '.NET Full Stack Enterprise',
    description: 'Build scalable enterprise applications using C#, .NET Core, and Azure. The corporate standard for software architecture.',
    instructor: 'Microsoft MVP',
    category: 'CSE / IT',
    rating: '92% Match',
    year: 2023,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=1920&auto=format&fit=crop',
    tags: ['C#', '.NET', 'Enterprise'],
    seasons: DEFAULT_SEASONS
  },

  // 6. Artificial Intelligence
  {
    id: 'ai-2',
    type: 'series',
    title: 'Artificial Intelligence',
    description: 'From classical search algorithms to modern deep learning. A comprehensive study of AI theory and application.',
    instructor: 'Dr. Hinton',
    category: 'CSE / IT',
    rating: '98% Match',
    year: 2025,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?q=80&w=1920&auto=format&fit=crop',
    tags: ['AI', 'Theory', 'Robotics'],
    seasons: DEFAULT_SEASONS
  },

  // 7. Machine Learning
  {
    id: 'ml-1',
    type: 'series',
    title: 'Machine Learning A-Z',
    description: 'Supervised, Unsupervised, and Reinforcement Learning. Implement ML models with Scikit-Learn and TensorFlow.',
    instructor: 'Andrew N.',
    category: 'CSE / IT',
    rating: '96% Match',
    year: 2023,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1527474305487-b87b222841cc?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?q=80&w=1920&auto=format&fit=crop',
    tags: ['ML', 'Python', 'Algorithms'],
    seasons: DEFAULT_SEASONS
  },

  // 8. Azure Cloud Computing
  {
    id: 'azure-1',
    type: 'series',
    title: 'Azure Cloud Computing',
    description: 'Become a certified Azure Solutions Architect. Virtual Machines, VNETs, and Serverless computing.',
    instructor: 'Cloud Ninja',
    category: 'CSE / IT',
    rating: '94% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1920&auto=format&fit=crop',
    tags: ['Cloud', 'Azure', 'DevOps'],
    seasons: DEFAULT_SEASONS
  },

  // 9. Cyber Security (Movie)
  {
    id: 'sec-1',
    type: 'movie',
    title: 'Cyber Security: Zero Trust',
    description: 'Defend against modern threats. Ethical hacking, network security, and cryptography essentials.',
    instructor: 'Mr. Robot',
    category: 'CSE / IT',
    rating: '97% Match',
    year: 2023,
    duration: '2h 45m',
    thumbnail: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=1920&auto=format&fit=crop',
    tags: ['Security', 'Hacking', 'Network'],
  },

  // 10. QA Testing & Automation
  {
    id: 'qa-1',
    type: 'series',
    title: 'QA Testing & Automation',
    description: 'Manual testing is dead. Learn Selenium, Appium, and CI/CD pipelines for automated quality assurance.',
    instructor: 'Test Architect',
    category: 'CSE / IT',
    rating: '90% Match',
    year: 2023,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1537884944318-390069bb8665?q=80&w=1920&auto=format&fit=crop',
    tags: ['QA', 'Testing', 'Automation'],
    seasons: DEFAULT_SEASONS
  },

  // 11. Power BI (Movie)
  {
    id: 'pbi-1',
    type: 'movie',
    title: 'Power BI: Data Visualization',
    description: 'Transform boring spreadsheets into interactive dashboards. Master DAX and data modeling.',
    instructor: 'Data Viz Pro',
    category: 'CSE / IT',
    rating: '93% Match',
    year: 2024,
    duration: '1h 50m',
    thumbnail: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?q=80&w=1920&auto=format&fit=crop',
    tags: ['BI', 'Visualization', 'Analytics'],
  },

  // 12. DSA
  {
    id: 'dsa-1',
    type: 'series',
    title: 'Data Structures & Algorithms',
    description: 'Crack the coding interview. Master Arrays, Linked Lists, Trees, Graphs, and Dynamic Programming.',
    instructor: 'Algo Expert',
    category: 'CSE / IT',
    rating: '99% Match',
    year: 2022,
    duration: '4 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1662444391694-1a3eb8a92446?q=80&w=1920&auto=format&fit=crop',
    tags: ['DSA', 'Coding', 'Interviews'],
    seasons: DEFAULT_SEASONS
  },

  // 13. Android Development
  {
    id: 'android-1',
    type: 'series',
    title: 'Android Development',
    description: 'Build native mobile apps with Kotlin and Jetpack Compose. Publish your apps to the Play Store.',
    instructor: 'Google Developers',
    category: 'CSE / IT',
    rating: '95% Match',
    year: 2024,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1556656793-02715d8dd6f5?q=80&w=1920&auto=format&fit=crop',
    tags: ['Mobile', 'Android', 'Kotlin'],
    seasons: DEFAULT_SEASONS
  },

  // --- ECE / EEE DOMAINS ---

  // 14. AutoCAD (ECE)
  {
    id: 'ece-autocad',
    type: 'movie',
    title: 'AutoCAD Electrical',
    description: 'The standard for electrical design. Learn to create precise electrical schematics, control circuit diagrams, and panel layouts used in industrial automation.',
    instructor: 'Cadence Design',
    category: 'ECE / EEE',
    rating: '94% Match',
    year: 2024,
    duration: '2h 30m',
    thumbnail: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?q=80&w=1920&auto=format&fit=crop',
    tags: ['AutoCAD', 'Design', 'Schematics'],
  },

  // 15. Embedded Systems
  {
    id: 'ece-embedded',
    type: 'series',
    title: 'Embedded Systems: The Core',
    description: 'Bridge the gap between hardware and software. Master microcontrollers (ARM, AVR), firmware development, and Real-Time Operating Systems (RTOS).',
    instructor: 'Prof. Jack Ganssle',
    category: 'ECE / EEE',
    rating: '98% Match',
    year: 2024,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1553406830-ef2513450d76?q=80&w=1920&auto=format&fit=crop',
    tags: ['Embedded', 'C', 'RTOS', 'Microcontrollers'],
    seasons: DEFAULT_SEASONS
  },

  // 16. VLSI
  {
    id: 'ece-vlsi',
    type: 'series',
    title: 'VLSI Design & Verification',
    description: 'Design the chips that power the world. From digital logic to physical design, learn Verilog, SystemVerilog, and FPGA prototyping techniques.',
    instructor: 'Silicon Valley Inst.',
    category: 'ECE / EEE',
    rating: '96% Match',
    year: 2023,
    duration: '4 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1597852074816-d933c7d2b988?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1530482054429-cc491f61333b?q=80&w=1920&auto=format&fit=crop',
    tags: ['VLSI', 'Verilog', 'FPGA', 'Chips'],
    seasons: DEFAULT_SEASONS
  },

  // 17. IoT
  {
    id: 'ece-iot',
    type: 'series',
    title: 'Internet of Things (IoT)',
    description: 'Connect the physical world to the cloud. Explore sensors, communication protocols (MQTT, CoAP), and edge computing architectures.',
    instructor: 'Smart Things Lab',
    category: 'ECE / EEE',
    rating: '95% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?q=80&w=1920&auto=format&fit=crop',
    tags: ['IoT', 'Sensors', 'Cloud', 'Automation'],
    seasons: DEFAULT_SEASONS
  },

  // 18. Robotics
  {
    id: 'ece-robotics',
    type: 'series',
    title: 'Robotics & Control Systems',
    description: 'Build autonomous machines. A deep dive into kinematics, dynamics, sensors, and control theory used in modern industrial and service robotics.',
    instructor: 'Boston Dynamics Team',
    category: 'ECE / EEE',
    rating: '99% Match',
    year: 2025,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1561557944-6e7860d1a7eb?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?q=80&w=1920&auto=format&fit=crop',
    tags: ['Robotics', 'Automation', 'Control Systems'],
    seasons: DEFAULT_SEASONS
  },

  // 19. Hybrid and Electric Vehicles (ECE)
  {
    id: 'eee-hev',
    type: 'series',
    title: 'Hybrid and Electric Vehicles',
    description: 'The future of transportation is electric. Understand battery management systems (BMS), power electronics, and motor drive technologies.',
    instructor: 'Elon M.',
    category: 'ECE / EEE',
    rating: '97% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?q=80&w=1920&auto=format&fit=crop',
    tags: ['EV', 'Hybrid', 'Batteries', 'Power Electronics'],
    seasons: DEFAULT_SEASONS
  },

  // --- MECHANICAL ENGINEERING DOMAIN ---

  // 20. IC Engine
  {
    id: 'mech-ic-engine',
    type: 'series',
    title: 'IC Engine: Power & Torque',
    description: 'The heartbeat of the automotive world. A cinematic journey into thermodynamics, combustion cycles, and high-performance engine tuning.',
    instructor: 'Prof. Diesel',
    category: 'Mechanical',
    rating: '98% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1562916190-6435c448882b?q=80&w=1920&auto=format&fit=crop',
    tags: ['Automotive', 'Thermodynamics', 'Engines'],
    seasons: DEFAULT_SEASONS
  },

  // 21. AutoCAD (Mechanical)
  {
    id: 'mech-autocad',
    type: 'series',
    title: 'AutoCAD Mechanical Design',
    description: 'From concept to blueprint. Master 2D drafting, 3D modeling, GD&T, and assembly design for manufacturing.',
    instructor: 'Autodesk Certified',
    category: 'Mechanical',
    rating: '95% Match',
    year: 2023,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1581094288338-2314dddb7ece?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1580983218765-f663bec07b37?q=80&w=1920&auto=format&fit=crop',
    tags: ['CAD', 'Design', 'Drafting'],
    seasons: DEFAULT_SEASONS
  },

  // 22. Hybrid & Electric Vehicles (Mechanical Focus)
  {
    id: 'mech-hev',
    type: 'series',
    title: 'EV Architecture & Chassis',
    description: 'Reinventing the wheel. Focus on the mechanical integration of battery packs, thermal management systems, and electric drivetrains.',
    instructor: 'Automotive Engineers',
    category: 'Mechanical',
    rating: '97% Match',
    year: 2025,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1558980394-4c7c9299fe96?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?q=80&w=1920&auto=format&fit=crop',
    tags: ['EV', 'Chassis', 'Thermal'],
    seasons: DEFAULT_SEASONS
  },

  // 23. Car Design
  {
    id: 'mech-car-design',
    type: 'series',
    title: 'Automotive Styling & Design',
    description: 'Where art meets aerodynamics. Learn sketching, clay modeling, and surface design from world-class automotive designers.',
    instructor: 'Pininfarina Studio',
    category: 'Mechanical',
    rating: '99% Match',
    year: 2024,
    duration: '1 Season',
    thumbnail: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1618331835717-801e976710b2?q=80&w=1920&auto=format&fit=crop',
    tags: ['Design', 'Styling', 'Aerodynamics'],
    seasons: DEFAULT_SEASONS
  },

  // --- CIVIL ENGINEERING DOMAIN ---

  // 24. Civil Engineering Fundamentals
  {
    id: 'civil-fundamentals',
    type: 'series',
    title: 'Civil Engineering Fundamentals',
    description: 'The foundation of modern infrastructure. Master the core principles of statics, strength of materials, and fluid mechanics.',
    instructor: 'Prof. Buildington',
    category: 'Civil',
    rating: '96% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?q=80&w=1920&auto=format&fit=crop',
    tags: ['Statics', 'Materials', 'Physics'],
    seasons: DEFAULT_SEASONS
  },

  // 25. AutoCAD (Civil)
  {
    id: 'civil-autocad-design',
    type: 'series',
    title: 'AutoCAD: Civil 3D & Design',
    description: 'Drafting the world around us. Learn topography modeling, road design, and structural detailing using industry-standard CAD tools.',
    instructor: 'Autodesk Certified',
    category: 'Civil',
    rating: '98% Match',
    year: 2023,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=1920&auto=format&fit=crop',
    tags: ['AutoCAD', 'Civil 3D', 'Drafting'],
    seasons: DEFAULT_SEASONS
  },

  // 26. Construction Planning & Design
  {
    id: 'civil-construction-planning',
    type: 'movie',
    title: 'Construction Planning & Design',
    description: 'Managing the mega-projects. A cinematic look into project estimation, site logistics, safety protocols, and resource management.',
    instructor: 'Project Lead',
    category: 'Civil',
    rating: '95% Match',
    year: 2025,
    duration: '2h 30m',
    thumbnail: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1590644365607-1c5a38d073cc?q=80&w=1920&auto=format&fit=crop',
    tags: ['Management', 'Planning', 'Safety'],
  },

  // --- MANAGEMENT / B.COM DOMAIN ---

  // 27. Strategic Management
  {
    id: 'mgmt-strategy',
    type: 'series',
    title: 'Strategic Business Management',
    description: 'Navigate the complexities of modern business. Learn to formulate strategies, analyze markets, and lead organizations to success.',
    instructor: 'Harvard Business Rev.',
    category: 'Management',
    rating: '97% Match',
    year: 2024,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1920&auto=format&fit=crop',
    tags: ['Leadership', 'Strategy', 'Business'],
    seasons: DEFAULT_SEASONS
  },

  // 28. Human Resources
  {
    id: 'mgmt-hr',
    type: 'series',
    title: 'Human Resources: Talent & Culture',
    description: 'People are your greatest asset. Master recruitment, employee engagement, conflict resolution, and organizational culture building.',
    instructor: 'Chief People Officer',
    category: 'Management',
    rating: '95% Match',
    year: 2023,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=1920&auto=format&fit=crop',
    tags: ['HR', 'Recruitment', 'Culture'],
    seasons: DEFAULT_SEASONS
  },

  // 29. Digital Marketing
  {
    id: 'mgmt-digital-marketing',
    type: 'series',
    title: 'Digital Marketing: The Viral Age',
    description: 'Dominate the digital landscape. A comprehensive guide to SEO, Social Media Marketing, Content Strategy, and PPC advertising.',
    instructor: 'Google Certified',
    category: 'Management',
    rating: '99% Match',
    year: 2025,
    duration: '4 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1920&auto=format&fit=crop',
    tags: ['Marketing', 'SEO', 'Social Media'],
    seasons: DEFAULT_SEASONS
  },

  // 30. Mutual Funds & Stock Market
  {
    id: 'mgmt-stocks',
    type: 'movie',
    title: 'Wall Street: Mutual Funds & Stocks',
    description: 'Unlock the secrets of wealth creation. Understand technical analysis, portfolio diversification, and the psychology of trading.',
    instructor: 'Warren B.',
    category: 'Management',
    rating: '98% Match',
    year: 2024,
    duration: '2h 45m',
    thumbnail: 'https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1559589689-577aabd1e51f?q=80&w=1920&auto=format&fit=crop',
    tags: ['Finance', 'Trading', 'Investing'],
  },

  // 31. Finance
  {
    id: 'mgmt-finance',
    type: 'series',
    title: 'Corporate Finance & Valuation',
    description: 'The language of business. Deep dive into financial modeling, cash flow analysis, and capital budgeting decisions.',
    instructor: 'CFA Institute',
    category: 'Management',
    rating: '94% Match',
    year: 2023,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1565514020176-87d298fb6955?q=80&w=1920&auto=format&fit=crop',
    tags: ['Finance', 'Accounting', 'Business'],
    seasons: DEFAULT_SEASONS
  },

  // 32. Tally
  {
    id: 'mgmt-tally',
    type: 'series',
    title: 'Tally Prime: Accounting Mastery',
    description: 'Streamline your accounts. Master inventory management, GST compliance, and payroll processing using Tally Prime.',
    instructor: 'Tally Expert',
    category: 'Management',
    rating: '96% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1554224154-260327c00c4b?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?q=80&w=1920&auto=format&fit=crop',
    tags: ['Tally', 'Accounting', 'GST'],
    seasons: DEFAULT_SEASONS
  },

  // --- PHARMACY DOMAIN ---

  // 33. Clinical Pharmacy
  {
    id: 'pharma-clinical',
    type: 'series',
    title: 'Clinical Pharmacy & Therapeutics',
    description: 'The art of patient care. Master drug therapy management, pharmacokinetics, and evidence-based medicine in a hospital setting.',
    instructor: 'Dr. House',
    category: 'Pharmacy',
    rating: '98% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1551076805-e1869033e561?q=80&w=1920&auto=format&fit=crop',
    tags: ['Clinical', 'Medicine', 'Therapeutics'],
    seasons: DEFAULT_SEASONS
  },

  // 34. Pharmacology
  {
    id: 'pharma-pharmacology',
    type: 'series',
    title: 'Pharmacology: The Drug Action',
    description: 'A deep dive into pharmacodynamics and pharmacokinetics. Understand how drugs interact with biological systems to treat disease.',
    instructor: 'Prof. Receptor',
    category: 'Pharmacy',
    rating: '96% Match',
    year: 2023,
    duration: '3 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?q=80&w=1920&auto=format&fit=crop',
    tags: ['Pharmacology', 'Biology', 'Drugs'],
    seasons: DEFAULT_SEASONS
  },

  // 35. Medicinal Chemistry
  {
    id: 'pharma-chem',
    type: 'movie',
    title: 'Medicinal Chemistry: Drug Design',
    description: 'From molecule to medicine. Explore the chemical structure-activity relationships (SAR) that drive modern drug discovery.',
    instructor: 'Dr. Heisenberg',
    category: 'Pharmacy',
    rating: '95% Match',
    year: 2025,
    duration: '2h 15m',
    thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1530026405186-ed1f139313f8?q=80&w=1920&auto=format&fit=crop',
    tags: ['Chemistry', 'Research', 'Discovery'],
  },

  // 36. Pharmaceutics
  {
    id: 'pharma-ceutics',
    type: 'series',
    title: 'Pharmaceutics & Formulation',
    description: 'The science of dosage forms. Learn how to formulate tablets, capsules, and injectables for optimal drug delivery.',
    instructor: 'Pharma Tech',
    category: 'Pharmacy',
    rating: '94% Match',
    year: 2024,
    duration: '2 Seasons',
    thumbnail: 'https://images.unsplash.com/photo-1631549916768-4119b2e5f926?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1579165466741-7f35a4755657?q=80&w=1920&auto=format&fit=crop',
    tags: ['Formulation', 'Manufacturing', 'Lab'],
    seasons: DEFAULT_SEASONS
  },

  // --- OTHER DOMAINS (Retained for variety) ---
  {
    id: 'mech-1',
    type: 'movie',
    title: 'Quantum Mechanics 101',
    description: 'Dive deep into the subatomic world. This feature-length course breaks down complex physics.',
    instructor: 'Prof. Richard Fey',
    category: 'Mechanical',
    rating: '95% Match',
    year: 2023,
    duration: '2h 15m',
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=1920&auto=format&fit=crop',
    tags: ['Physics', 'Science'],
  },
  {
    id: 'agri-1',
    type: 'movie',
    title: 'Modern Agriculture',
    description: 'How drones and IoT are revolutionizing farming.',
    instructor: 'AgriTech Labs',
    category: 'Agriculture',
    rating: '88% Match',
    year: 2023,
    duration: '1h 30m',
    thumbnail: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1625246333195-09870c66438e?q=80&w=1920&auto=format&fit=crop',
    tags: ['Farming', 'IoT'],
  },
  {
    id: 'comm-1',
    type: 'movie',
    title: 'Mastering Public Speaking',
    description: 'Unlock your confidence and captivate any audience.',
    instructor: 'Ted Talker',
    category: 'Creative',
    rating: '94% Match',
    year: 2023,
    duration: '1h 20m',
    thumbnail: 'https://images.unsplash.com/photo-1560439514-e960a3ef5019?q=80&w=400&auto=format&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=1920&auto=format&fit=crop',
    tags: ['Communication', 'Soft Skills'],
  }
];

export const FEATURED_CONTENT = CONTENT_DATA[0];