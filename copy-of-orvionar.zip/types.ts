export type Category = 
  | 'CSE / IT' 
  | 'ECE / EEE' 
  | 'Mechanical' 
  | 'Civil' 
  | 'Management' 
  | 'Pharmacy' 
  | 'Agriculture' 
  | 'Creative';

export interface Episode {
  id: string;
  title: string;
  duration: string;
  description: string;
  thumbnail: string;
  isCompleted?: boolean;
}

export interface Season {
  id: string;
  title: string;
  episodes: Episode[];
}

export interface ContentItem {
  id: string;
  type: 'movie' | 'series';
  title: string;
  description: string;
  instructor: string;
  category: Category;
  rating: string; // e.g., "4.8", "5.0"
  year: number;
  duration: string; // "2h 15m" or "3 Seasons"
  thumbnail: string; // Poster
  backdrop: string; // Wide hero image
  tags: string[];
  progress?: number; // 0 to 100
  
  // Specific to Movie (Single Course)
  videoUrl?: string; // Mock URL
  
  // Specific to Series (Learning Path)
  seasons?: Season[];
}