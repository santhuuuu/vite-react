import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import ContentCard from '../components/ContentCard';
import { ContentItem } from '../types';

const ViewAll: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  // Retrieve passed state
  const { title, items } = location.state as { title: string; items: ContentItem[] } || { title: '', items: [] };

  if (!items || items.length === 0) {
    return (
         <div className="min-h-screen bg-brand-dark text-white pt-24 px-12 flex flex-col items-center">
            <p className="text-xl text-gray-400">No content available for this selection.</p>
            <button 
              onClick={() => navigate('/')} 
              className="text-brand-orange mt-6 hover:underline font-bold"
            >
              Back to Home
            </button>
         </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-dark text-white pt-24 px-4 md:px-12 pb-12 animate-fade-in">
       {/* Header - Transparent/Glassy */}
       <div className="flex items-center gap-4 mb-8 sticky top-[60px] z-30 py-4 bg-gradient-to-b from-brand-dark via-brand-dark/80 to-transparent backdrop-blur-sm -mx-4 px-4 md:-mx-12 md:px-12">
          <button 
            onClick={() => navigate(-1)} 
            className="hover:bg-white/10 p-2 rounded-full transition-colors group"
          >
             <ArrowLeft className="w-6 h-6 text-white group-hover:text-brand-orange" />
          </button>
          <h1 className="text-2xl md:text-4xl font-extrabold tracking-tight drop-shadow-lg">
            {title}
          </h1>
          <span className="text-gray-400 text-sm md:text-base mt-2 ml-2 drop-shadow-md">
            ({items.length} titles)
          </span>
       </div>

       {/* Grid */}
       <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-8">
          {items.map(item => (
             <ContentCard key={item.id} item={item} fluid />
          ))}
       </div>
    </div>
  );
}

export default ViewAll;