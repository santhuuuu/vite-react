import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Play, Plus, ThumbsUp, ChevronDown } from 'lucide-react';
import { CONTENT_DATA } from '../constants';
import ContentRow from '../components/ContentRow';

const Details: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const content = CONTENT_DATA.find(c => c.id === id);

  if (!content) {
    return <div className="text-white text-center pt-40">Content not found.</div>;
  }

  // Find similar items based on category
  const similarContent = CONTENT_DATA.filter(c => c.category === content.category && c.id !== content.id);

  return (
    <div className="min-h-screen bg-brand-dark text-white pb-20">
      {/* Detail Hero */}
      <div className="relative h-[70vh] w-full">
        <div className="absolute inset-0">
          <img src={content.backdrop} alt={content.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-brand-dark/50 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-brand-dark via-brand-dark/20 to-transparent"></div>
        </div>

        <div className="relative h-full flex items-end px-4 md:px-12 pb-12">
          <div className="max-w-3xl space-y-6 animate-fade-in">
             <div className="flex flex-wrap gap-2 md:gap-4 items-center uppercase tracking-wider font-bold text-sm text-gray-300">
                <span className="text-brand-orange">Original</span>
                <span className="bg-gray-800 px-2 py-1 rounded border border-gray-600">{content.category}</span>
                <span>{content.year}</span>
                <span>{content.duration}</span>
             </div>
             
             <h1 className="text-4xl md:text-6xl font-extrabold drop-shadow-lg">{content.title}</h1>
             
             <div className="flex items-center gap-4">
               <span className="text-green-500 font-bold">{content.rating} Match</span>
               <span className="text-gray-300">Instructor: {content.instructor}</span>
             </div>

             <div className="flex gap-4 pt-2">
                <button 
                  onClick={() => navigate(`/watch/${content.id}`)}
                  className="bg-white text-black px-8 py-3 rounded font-bold flex items-center gap-2 hover:bg-gray-200 transition transform hover:scale-105"
                >
                  <Play className="fill-black" /> {content.progress && content.progress > 0 ? 'Resume' : 'Play'}
                </button>
                <button className="bg-gray-600/60 backdrop-blur-md text-white px-4 py-3 rounded-full hover:bg-gray-500 transition border border-gray-400">
                  <Plus />
                </button>
                <button className="bg-gray-600/60 backdrop-blur-md text-white px-4 py-3 rounded-full hover:bg-gray-500 transition border border-gray-400">
                  <ThumbsUp />
                </button>
             </div>
          </div>
        </div>
      </div>

      <div className="px-4 md:px-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Left Column: Description & Episodes */}
        <div className="lg:col-span-2 space-y-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-gray-400">Description</h3>
            <p className="text-lg leading-relaxed text-gray-100">{content.description}</p>
            <div className="flex gap-2 flex-wrap">
              {content.tags.map(tag => (
                <span key={tag} className="text-sm text-gray-400 bg-gray-800 px-2 py-1 rounded">#{tag}</span>
              ))}
            </div>
          </div>

          {/* Episodes / Curriculum Section */}
          <div className="pt-8">
             <div className="flex items-center justify-between mb-6 border-b border-gray-700 pb-2">
                <h2 className="text-2xl font-bold text-brand-orange">
                  {content.type === 'series' ? 'Episodes' : 'Curriculum'}
                </h2>
                {content.type === 'series' && (
                  <button className="text-lg font-bold flex items-center gap-2 text-gray-300 hover:text-white transition">
                    Season 1 <ChevronDown className="w-4 h-4" />
                  </button>
                )}
             </div>

             <div className="space-y-4">
                {content.type === 'series' ? (
                  content.seasons && content.seasons.length > 0 && content.seasons[0].episodes && content.seasons[0].episodes.length > 0 ? (
                    content.seasons[0].episodes.map((ep, idx) => (
                      <div 
                        key={ep.id} 
                        className="group flex flex-col md:flex-row gap-4 items-center p-4 hover:bg-gray-800 rounded transition cursor-pointer border-b border-gray-800 md:border-none"
                        onClick={() => navigate(`/watch/${content.id}?ep=${ep.id}`)}
                      >
                        <span className="text-2xl font-bold text-gray-500 w-8">{idx + 1}</span>
                        <div className="relative w-full md:w-40 aspect-video rounded overflow-hidden flex-shrink-0 bg-gray-900">
                          <img 
                            src={ep.thumbnail || content.thumbnail} 
                            className="w-full h-full object-cover group-hover:scale-110 transition duration-500" 
                            alt={ep.title}
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                            <Play className="fill-white w-8 h-8" />
                          </div>
                          {/* Progress bar mock */}
                          {ep.isCompleted && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-orange"></div>}
                        </div>
                        <div className="flex-1 w-full">
                            <div className="flex justify-between items-center mb-1">
                              <h4 className="font-bold text-lg text-gray-100 group-hover:text-brand-orange transition">{ep.title}</h4>
                              <span className="text-sm text-gray-400">{ep.duration}</span>
                            </div>
                            <p className="text-gray-400 text-sm line-clamp-2">{ep.description}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-8 text-center text-gray-500 bg-gray-900/50 rounded-lg border border-gray-800/50">
                      <p className="italic">Episodes for this season are coming soon.</p>
                    </div>
                  )
                ) : (
                  // Movie Curriculum Mock (Single "Episode")
                  <div 
                    className="group flex flex-col md:flex-row gap-4 items-center p-4 hover:bg-gray-800 rounded transition cursor-pointer border border-gray-800 hover:border-brand-orange/50"
                    onClick={() => navigate(`/watch/${content.id}`)}
                  >
                     <div className="relative w-full md:w-40 aspect-video rounded overflow-hidden flex-shrink-0 bg-gray-900">
                        <img 
                          src={content.thumbnail} 
                          className="w-full h-full object-cover group-hover:scale-110 transition duration-500" 
                          alt={content.title}
                        />
                         <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                            <Play className="fill-white w-8 h-8" />
                          </div>
                     </div>
                     <div className="flex-1">
                        <h4 className="font-bold text-lg text-white mb-1">Full Course: {content.title}</h4>
                        <p className="text-gray-400 text-sm">Watch the complete feature-length course in one session.</p>
                        <span className="text-brand-orange text-xs font-bold mt-2 block uppercase tracking-wider">Click to Play</span>
                     </div>
                  </div>
                )}
             </div>
          </div>
        </div>

        {/* Right Column: Meta & Recommendations */}
        <div className="space-y-8">
           <div className="bg-gray-900/50 p-6 rounded-lg space-y-4 border border-white/5 backdrop-blur-sm">
              <div>
                <span className="text-gray-500 text-sm block font-semibold uppercase mb-1">Instructor</span>
                <span className="text-white text-lg">{content.instructor}</span>
              </div>
              <div className="h-px bg-gray-700/50 my-2"></div>
              <div>
                <span className="text-gray-500 text-sm block font-semibold uppercase mb-1">Category</span>
                <span className="text-white text-lg">{content.category}</span>
              </div>
              <div className="h-px bg-gray-700/50 my-2"></div>
              <div>
                <span className="text-gray-500 text-sm block font-semibold uppercase mb-1">Level</span>
                <span className="text-white text-lg">Intermediate / Advanced</span>
              </div>
           </div>
        </div>
      </div>

      {similarContent.length > 0 && (
         <div className="mt-12">
            <ContentRow title="More Like This" items={similarContent} />
         </div>
      )}
    </div>
  );
};

export default Details;