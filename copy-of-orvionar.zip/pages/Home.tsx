import React, { useState, useMemo } from 'react';
import { 
  Cpu, Zap, Settings, Building2, Briefcase, Pill, Sprout, Mic, LayoutGrid, ChevronDown 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Hero from '../components/Hero';
import ContentRow from '../components/ContentRow';
import { CONTENT_DATA, FEATURED_CONTENT } from '../constants';
import { ContentItem } from '../types';

const Home: React.FC = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('All Domains');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Define categories with icons
  const categories = [
    { name: 'All Domains', icon: LayoutGrid },
    { name: 'CSE / IT', icon: Cpu },
    { name: 'ECE / EEE', icon: Zap },
    { name: 'Mechanical', icon: Settings },
    { name: 'Civil', icon: Building2 },
    { name: 'Management', icon: Briefcase },
    { name: 'Pharmacy', icon: Pill },
    { name: 'Agriculture', icon: Sprout },
    { name: 'Creative', icon: Mic },
  ];

  // Dynamic Content Filtering
  const filteredContent = useMemo(() => {
    if (selectedCategory === 'All Domains') {
      return CONTENT_DATA;
    }
    return CONTENT_DATA.filter(item => item.category === selectedCategory || item.category.includes(selectedCategory));
  }, [selectedCategory]);

  // Determine Hero Content
  const heroContent = useMemo(() => {
    if (selectedCategory === 'All Domains') {
      return FEATURED_CONTENT;
    }
    return filteredContent[0] || FEATURED_CONTENT;
  }, [selectedCategory, filteredContent]);

  // Navigation Handler for "Explore All"
  const handleExplore = (title: string, items: ContentItem[]) => {
    navigate('/view-all', { state: { title, items } });
  };

  // Derived Filters for Rows
  const continueWatching = filteredContent.filter(item => item.progress && item.progress > 0);
  const series = filteredContent.filter(item => item.type === 'series');
  const guidance = filteredContent.filter(item => item.type === 'movie');

  // Helper for "All Domains" specific rows
  const getCategoryItems = (cat: string) => CONTENT_DATA.filter(item => item.category === cat);
  const engineeringItems = CONTENT_DATA.filter(item => ['Mechanical', 'Civil', 'ECE / EEE'].includes(item.category));
  const lifeScienceItems = CONTENT_DATA.filter(item => ['Pharmacy', 'Agriculture'].includes(item.category));
  const businessItems = CONTENT_DATA.filter(item => ['Management', 'Creative'].includes(item.category));

  return (
    <div className="bg-brand-dark min-h-screen pb-20">
      
      {/* Category Dropdown Filter */}
      <div className="fixed top-[60px] md:top-[70px] left-0 right-0 z-40 px-4 md:px-12 py-4 flex items-center gap-4 animate-fade-in pointer-events-none">
        <div className="pointer-events-auto relative">
           <button
             onClick={() => setIsDropdownOpen(!isDropdownOpen)}
             className="flex items-center gap-2 bg-transparent text-white text-xl font-bold tracking-tight hover:opacity-80 transition-all group focus:outline-none shadow-black drop-shadow-md"
           >
             {selectedCategory}
             <ChevronDown className={`w-5 h-5 transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : 'group-hover:translate-y-1'}`} />
           </button>

           {/* Dropdown Menu */}
           {isDropdownOpen && (
             <div className="absolute top-full left-0 mt-2 w-64 bg-brand-dark/90 backdrop-blur-xl border border-white/10 shadow-2xl rounded-md p-2 flex flex-col gap-1 max-h-[60vh] overflow-y-auto no-scrollbar">
               {categories.map((cat) => {
                 const Icon = cat.icon;
                 return (
                   <button
                     key={cat.name}
                     onClick={() => {
                       setSelectedCategory(cat.name);
                       setIsDropdownOpen(false);
                     }}
                     className={`text-left px-4 py-3 text-sm flex items-center gap-3 transition-colors rounded-sm ${
                       selectedCategory === cat.name 
                         ? 'bg-white/10 text-white font-bold border-l-4 border-brand-orange' 
                         : 'text-gray-400 hover:bg-white/5 hover:text-white'
                     }`}
                   >
                     <Icon className="w-4 h-4" />
                     {cat.name}
                   </button>
                 );
               })}
             </div>
           )}
        </div>
        
        {/* Breadcrumb / Label */}
        <div className="text-gray-400 text-sm font-medium tracking-wide hidden md:block pl-4 flex items-center h-5 drop-shadow-md">
           {selectedCategory === 'All Domains' ? 'Browse' : 'Filtered View'}
        </div>
      </div>

      {/* Hero Section */}
      <Hero content={heroContent} />
      
      {/* Content Rows */}
      <div className="-mt-20 relative z-20 space-y-6">
        
        {continueWatching.length > 0 && (
          <ContentRow 
            title="Continue Learning" 
            items={continueWatching} 
            large 
            onExplore={() => handleExplore('Continue Learning', continueWatching)}
          />
        )}

        {selectedCategory === 'All Domains' ? (
          // Default Layout for "All Domains"
          <>
            <ContentRow 
              title="Trending Web Series (Learning Paths)" 
              items={series.slice(0, 5)} 
              onExplore={() => handleExplore('Trending Web Series', series)} 
            />
            <ContentRow 
              title="Career Guidance & Specials" 
              items={guidance} 
              onExplore={() => handleExplore('Career Guidance', guidance)}
            />
            <ContentRow 
              title="Tech & Innovation (CSE / IT)" 
              items={getCategoryItems('CSE / IT')} 
              onExplore={() => handleExplore('Tech & Innovation', getCategoryItems('CSE / IT'))}
            />
            <ContentRow 
              title="Core Engineering (Mech, Civil, EEE)" 
              items={engineeringItems} 
              onExplore={() => handleExplore('Core Engineering', engineeringItems)}
            />
            <ContentRow 
              title="Life Sciences & Agriculture" 
              items={lifeScienceItems} 
              onExplore={() => handleExplore('Life Sciences & Agriculture', lifeScienceItems)}
            />
            <ContentRow 
              title="Business & Leadership" 
              items={businessItems} 
              onExplore={() => handleExplore('Business & Leadership', businessItems)}
            />
          </>
        ) : (
          // Filtered Layout for Specific Category
          <>
            <ContentRow 
              title={`Trending in ${selectedCategory}`} 
              items={filteredContent} 
              onExplore={() => handleExplore(selectedCategory, filteredContent)}
            />
            {series.length > 0 && (
              <ContentRow 
                title="Binge-worthy Series" 
                items={series} 
                onExplore={() => handleExplore(`${selectedCategory} Series`, series)}
              />
            )}
            {guidance.length > 0 && (
              <ContentRow 
                title="Career Guidance Sessions" 
                items={guidance} 
                onExplore={() => handleExplore(`${selectedCategory} Guidance`, guidance)}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Home;