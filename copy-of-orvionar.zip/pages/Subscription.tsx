import React from 'react';
import { Check, Crown } from 'lucide-react';

const Subscription: React.FC = () => {
  const plans = [
    {
      id: 'weekly',
      name: 'Weekly Pass',
      price: '₹250',
      period: '/ week',
      features: ['Access to all courses', 'HD Video Quality', 'Mobile Access Only', 'Cancel anytime'],
      isPopular: false,
    },
    {
      id: 'monthly',
      name: 'Monthly Plan',
      price: '₹500',
      period: '/ month',
      features: ['Access to all courses', 'Full HD 1080p', 'Watch on Laptop & Mobile', 'Offline Downloads', 'Cancel anytime'],
      isPopular: true,
    },
    {
      id: 'yearly',
      name: 'Yearly Pro',
      price: '₹4000',
      period: '/ year',
      features: ['Access to all courses', '4K Ultra HD', 'Watch on All Devices', 'Offline Downloads', 'Course Certificates', 'Priority Support'],
      isPopular: false,
      savings: 'Save ₹2000'
    },
  ];

  return (
    <div className="min-h-screen bg-brand-dark text-white pt-24 px-4 md:px-12 pb-20 animate-fade-in flex flex-col items-center justify-center">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
        <div className="inline-flex items-center gap-2 bg-gradient-to-r from-brand-orange to-red-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2 border border-white/20">
            <Crown className="w-3 h-3 fill-white" />
            <span>Premium Access</span>
        </div>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
          Invest in your <span className="text-brand-orange">Future</span>.
        </h1>
        <p className="text-gray-400 text-lg md:text-xl leading-relaxed">
          Unlock unlimited access to cinematic career guidance, web series, and professional courses. Choose the plan that fits your journey.
        </p>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
        {plans.map((plan) => (
          <div 
            key={plan.id} 
            className={`relative bg-gray-900/40 backdrop-blur-xl border rounded-2xl p-8 flex flex-col transition-all duration-300 group
              ${plan.isPopular 
                ? 'border-brand-orange shadow-2xl shadow-brand-orange/20 scale-100 md:scale-110 z-10' 
                : 'border-white/10 hover:border-white/30 hover:bg-gray-800/60'
              }`}
          >
            {plan.isPopular && (
               <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-brand-orange text-white px-6 py-1.5 rounded-full text-xs font-extrabold tracking-widest uppercase shadow-lg">
                 Most Popular
               </div>
            )}
            
            {plan.savings && (
                <div className="absolute top-4 right-4 bg-green-500/10 text-green-400 text-[10px] font-bold border border-green-500/50 px-2 py-1 rounded uppercase tracking-wide">
                    {plan.savings}
                </div>
            )}

            <div className="mb-6">
                <h3 className={`text-xl font-bold mb-2 ${plan.isPopular ? 'text-brand-orange' : 'text-gray-300'}`}>
                    {plan.name}
                </h3>
                <div className="flex items-baseline gap-1">
                <span className="text-4xl md:text-5xl font-extrabold text-white">{plan.price}</span>
                <span className="text-gray-500 font-medium">{plan.period}</span>
                </div>
            </div>

            <div className="space-y-4 flex-1 mb-8">
               {plan.features.map((feature, idx) => (
                 <div key={idx} className="flex items-start gap-3">
                   <div className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${plan.isPopular ? 'bg-brand-orange/20' : 'bg-gray-800'}`}>
                      <Check className={`w-3 h-3 ${plan.isPopular ? 'text-brand-orange' : 'text-gray-400'}`} />
                   </div>
                   <span className="text-gray-300 text-sm">{feature}</span>
                 </div>
               ))}
            </div>

            <button className={`w-full py-4 rounded-xl font-bold tracking-wide transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98]
               ${plan.isPopular 
                 ? 'bg-gradient-to-r from-brand-orange to-red-600 text-white shadow-lg shadow-orange-900/40 hover:shadow-orange-700/50' 
                 : 'bg-white text-black hover:bg-gray-200'
               }`}>
               Choose {plan.name}
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-16 text-center space-y-2">
         <p className="text-gray-500 text-sm">
            * Secure payment processing. Cancel automatically in your dashboard.
         </p>
         <div className="flex gap-4 justify-center text-xs text-gray-600 uppercase tracking-widest">
            <span>Secure SSL</span>
            <span>•</span>
            <span>24/7 Support</span>
            <span>•</span>
            <span>Money Back Guarantee</span>
         </div>
      </div>
    </div>
  );
};

export default Subscription;