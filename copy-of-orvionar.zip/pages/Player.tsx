import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, SkipForward, Volume2, Settings, Maximize } from 'lucide-react';

const Player: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  return (
    <div className="fixed inset-0 z-[60] bg-black flex items-center justify-center overflow-hidden">
      
      {/* Mock Video Container */}
      <div className="relative w-full h-full bg-black group">
        
        {/* Placeholder for Video */}
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
             <div className="text-center">
               <h2 className="text-2xl text-gray-500 mb-2">Video Player Simulation</h2>
               <p className="text-gray-600">Playing Content ID: {id}</p>
             </div>
        </div>

        {/* Controls Overlay (Visible on Hover) */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-8">
           
           {/* Top Bar */}
           <div className="flex items-center gap-4">
              <button onClick={() => navigate(-1)} className="hover:scale-110 transition">
                <ArrowLeft className="w-8 h-8 text-white" />
              </button>
              <div>
                <h2 className="text-white font-bold text-xl">The AI Revolution</h2>
                <span className="text-gray-300 text-sm">S1:E1 Birth of a Brain</span>
              </div>
           </div>

           {/* Bottom Bar */}
           <div className="space-y-4">
              {/* Progress Bar */}
              <div className="w-full bg-gray-600 h-1.5 rounded-full cursor-pointer relative group/bar">
                 <div className="bg-brand-orange h-full w-1/3 relative">
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 bg-brand-orange rounded-full scale-0 group-hover/bar:scale-100 transition"></div>
                 </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-6">
                    <button className="text-white font-bold hover:text-brand-orange">PLAY</button>
                    <button className="text-white hover:text-brand-orange rotate-180">
                       <span className="text-xs">10</span>
                    </button>
                    <button className="text-white hover:text-brand-orange">
                       <span className="text-xs">10</span>
                    </button>
                    <div className="flex items-center gap-2">
                       <Volume2 className="w-6 h-6 text-white" />
                    </div>
                 </div>

                 <div className="flex items-center gap-6">
                    <button className="text-white hover:text-gray-300 font-semibold flex items-center gap-2">
                       NEXT EPISODE <SkipForward className="w-5 h-5" />
                    </button>
                    <Settings className="w-6 h-6 text-white cursor-pointer" />
                    <Maximize className="w-6 h-6 text-white cursor-pointer" />
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Player;