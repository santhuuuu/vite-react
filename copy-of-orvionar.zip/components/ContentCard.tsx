import React from 'react';
import { PlayCircle } from 'lucide-react';
import { ContentItem } from '../types';
import { useNavigate } from 'react-router-dom';

interface ContentCardProps {
  item: ContentItem;
  large?: boolean; // For "Trending" or larger cards
  fluid?: boolean; // For Grid views (width: 100%)
}

const ContentCard: React.FC<ContentCardProps> = ({ item, large = false, fluid = false }) => {
  const navigate = useNavigate();

  // Determine width classes
  const widthClass = fluid 
    ? 'w-full' 
    : large 
      ? 'w-[200px] md:w-[300px]' 
      : 'w-[140px] md:w-[200px]';

  return (
    <div 
      className={`relative flex-none group cursor-pointer transition-all duration-300 ease-in-out transform hover:scale-105 hover:z-20 ${widthClass}`}
      onClick={() => navigate(`/details/${item.id}`)}
    >
      <div className={`relative overflow-hidden rounded-md shadow-lg bg-gray-800 ${large ? 'aspect-video' : 'aspect-[2/3]'}`}>
        <img 
          src={large ? item.backdrop : item.thumbnail} 
          alt={item.title} 
          className="w-full h-full object-cover transition-opacity duration-300 group-hover:opacity-60"
        />
        
        {/* Progress Bar for enrolled/started content */}
        {item.progress !== undefined && item.progress > 0 && (
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-700">
            <div className="h-full bg-brand-orange" style={{ width: `${item.progress}%` }}></div>
          </div>
        )}

        {/* Hover Overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
           <PlayCircle className="w-12 h-12 text-white fill-white/20 mb-2" />
           <p className="text-white text-center font-bold px-2 text-sm">{item.title}</p>
           <p className="text-green-400 text-xs font-semibold">{item.rating}</p>
           <div className="flex gap-2 mt-1">
             <span className="text-[10px] border border-white/50 px-1 rounded text-white">{item.duration}</span>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ContentCard;