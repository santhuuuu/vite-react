import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import ContentCard from './ContentCard';
import { ContentItem } from '../types';

interface ContentRowProps {
  title: string;
  items: ContentItem[];
  large?: boolean;
  onExplore?: () => void;
}

const ContentRow: React.FC<ContentRowProps> = ({ title, items, large, onExplore }) => {
  const rowRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth / 2 : scrollLeft + clientWidth / 2;
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (items.length === 0) return null;

  return (
    <div className="mb-8 md:mb-12 relative group pl-4 md:pl-12">
      <div 
        className={`flex items-center gap-2 mb-3 md:mb-4 inline-block ${onExplore ? 'cursor-pointer hover:text-brand-orange transition-colors' : ''}`}
        onClick={onExplore}
      >
        <h2 className="text-white text-lg md:text-2xl font-bold">
          {title}
        </h2>
        {onExplore && (
          <span className="text-brand-orange text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-[-10px] group-hover:translate-x-0 duration-300">
             Explore All &gt;
          </span>
        )}
      </div>

      <div className="relative">
        {/* Left Arrow */}
        <button 
          className="absolute left-0 top-0 bottom-0 z-30 bg-black/50 w-12 hover:bg-black/70 hidden md:group-hover:flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
          onClick={() => scroll('left')}
        >
          <ChevronLeft className="w-8 h-8 text-white" />
        </button>

        {/* Scrollable Container */}
        <div 
          ref={rowRef}
          className="flex gap-4 overflow-x-auto no-scrollbar pb-4 scroll-smooth"
        >
          {items.map((item) => (
            <ContentCard key={item.id} item={item} large={large} />
          ))}
        </div>

        {/* Right Arrow */}
        <button 
          className="absolute right-0 top-0 bottom-0 z-30 bg-black/50 w-12 hover:bg-black/70 hidden md:group-hover:flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
          onClick={() => scroll('right')}
        >
          <ChevronRight className="w-8 h-8 text-white" />
        </button>
      </div>
    </div>
  );
};

export default ContentRow;