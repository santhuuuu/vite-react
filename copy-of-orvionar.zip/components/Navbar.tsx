import React, { useState, useEffect } from 'react';
import { Search, Bell, User, Menu, Crown } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-black/70 backdrop-blur-xl shadow-lg border-b border-white/5' : 'bg-gradient-to-b from-black/90 to-transparent'}`}>
      <div className="px-4 md:px-12 py-4 flex flex-row items-center justify-between">
        
        {/* Left Side: Logo & Links */}
        <div className="flex items-center gap-8">
          <Link to="/" className="text-2xl md:text-3xl font-extrabold text-brand-orange tracking-tighter cursor-pointer drop-shadow-md">
            ORVIONAR
          </Link>
          
          <div className="hidden md:flex gap-6 text-sm font-medium text-gray-300">
            <Link to="/" className={`hover:text-white transition ${location.pathname === '/' ? 'text-white font-bold' : ''}`}>Home</Link>
            <Link to="/series" className="hover:text-white transition">Series</Link>
            <Link to="/guidance" className="hover:text-white transition">Career Guidance</Link>
            <Link to="/new" className="hover:text-white transition">New & Popular</Link>
            <Link to="/list" className="hover:text-white transition">My List</Link>
          </div>
        </div>

        {/* Right Side: Icons & Premium */}
        <div className="flex items-center gap-6 text-white">
          
          {/* Premium Subscription CTA */}
          <button 
            onClick={() => navigate('/subscription')}
            className="hidden sm:flex items-center gap-2 bg-gradient-to-r from-brand-orange to-red-600 px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider shadow-lg shadow-orange-900/40 hover:scale-105 transition transform border border-white/10 group cursor-pointer"
          >
             <Crown className="w-3 h-3 fill-white/80 group-hover:fill-white transition" />
             <span>Go Premium</span>
          </button>

          <div className="flex items-center gap-4">
            <Search className="w-5 h-5 cursor-pointer hover:text-brand-orange transition" />
            <Bell className="w-5 h-5 cursor-pointer hover:text-brand-orange transition hidden sm:block" />
            
            <div className="flex items-center gap-2 cursor-pointer group">
              <div className="w-8 h-8 rounded bg-brand-orange flex items-center justify-center shadow-lg shadow-orange-900/20 border border-white/10">
                 <User className="w-5 h-5 text-white" />
              </div>
            </div>
            <Menu className="w-6 h-6 md:hidden cursor-pointer" />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;