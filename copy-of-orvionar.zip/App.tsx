import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Details from './pages/Details';
import Player from './pages/Player';
import ViewAll from './pages/ViewAll';
import Subscription from './pages/Subscription';

// Helper to scroll to top on route change
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isPlayer = location.pathname.startsWith('/watch');

  return (
    <>
      {!isPlayer && <Navbar />}
      {children}
      
      {!isPlayer && (
        <footer className="bg-black py-12 px-4 md:px-12 text-gray-500 text-sm border-t border-gray-900">
           <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
              <div className="space-y-2">
                 <p className="hover:underline cursor-pointer">Audio Description</p>
                 <p className="hover:underline cursor-pointer">Investor Relations</p>
                 <p className="hover:underline cursor-pointer">Legal Notices</p>
              </div>
              <div className="space-y-2">
                 <p className="hover:underline cursor-pointer">Help Center</p>
                 <p className="hover:underline cursor-pointer">Jobs</p>
                 <p className="hover:underline cursor-pointer">Cookie Preferences</p>
              </div>
              <div className="space-y-2">
                 <p className="hover:underline cursor-pointer">Gift Cards</p>
                 <p className="hover:underline cursor-pointer">Terms of Use</p>
                 <p className="hover:underline cursor-pointer">Corporate Information</p>
              </div>
              <div className="space-y-2">
                 <p className="hover:underline cursor-pointer">Media Center</p>
                 <p className="hover:underline cursor-pointer">Privacy</p>
                 <p className="hover:underline cursor-pointer">Contact Us</p>
              </div>
           </div>
           <div className="max-w-6xl mx-auto">
             <button className="border border-gray-500 px-4 py-1 hover:text-white mb-4">
                Service Code
             </button>
             <p>&copy; 2024 Orvionar Education, Inc.</p>
           </div>
        </footer>
      )}
    </>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/details/:id" element={<Details />} />
          <Route path="/watch/:id" element={<Player />} />
          <Route path="/view-all" element={<ViewAll />} />
          <Route path="/subscription" element={<Subscription />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;